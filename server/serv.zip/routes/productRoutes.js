const express = require("express");

const {
  getPublicProducts,
  getPublicProductBySlug,
  getAdminProducts,
  createProduct,
  updateProduct,
  updateProductStatus,
  softDeleteProduct,
} = require("../controllers/productController");

const { authMiddleware, requireRole } = require("../middleware/authMiddleware");

const router = express.Router();

// Public website catalogue endpoints.
router.get("/", getPublicProducts);
router.get("/:slug", getPublicProductBySlug);

// CRM endpoints: admin and staff can manage catalogue records.
router.use("/admin", authMiddleware, requireRole("admin", "staff"));
router.get("/admin/all", getAdminProducts);

// All write operations require an authenticated admin or staff member.
router.post("/", authMiddleware, requireRole("admin", "staff"), createProduct);
router.patch("/:id", authMiddleware, requireRole("admin", "staff"), updateProduct);
router.patch("/:id/status", authMiddleware, requireRole("admin", "staff"), updateProductStatus);
router.delete("/:id", authMiddleware, requireRole("admin", "staff"), softDeleteProduct);

module.exports = router;
