const mongoose = require("mongoose");
const Product = require("../models/Product");
const { PRODUCT_CATEGORIES } = require("../models/Product");

const isValidId = (id) => mongoose.isValidObjectId(id);
const ALLOWED_FIELDS = [
  "name",
  "sku",
  "category",
  "description",
  "images",
  "metal",
  "purity",
  "grossWeight",
  "netWeight",
  "featured",
  "showOnWebsite",
];

const escapeRegex = (value = "") =>
  value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const makeSlug = (value) =>
  String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 180);

const publicProductFields =
  "name slug category description images metal purity grossWeight netWeight featured createdAt updatedAt";

const validateProductInput = (body, isUpdate = false) => {
  const errors = [];
  if (!isUpdate || Object.prototype.hasOwnProperty.call(body, "name")) {
    if (typeof body.name !== "string" || !body.name.trim()) {
      errors.push("Product name is required.");
    }
  }
  if (!isUpdate || Object.prototype.hasOwnProperty.call(body, "category")) {
    if (!PRODUCT_CATEGORIES.includes(body.category)) {
      errors.push(`Category must be one of: ${PRODUCT_CATEGORIES.join(", ")}.`);
    }
  }
  if (body.images !== undefined) {
    if (
      !Array.isArray(body.images) ||
      body.images.length > 12 ||
      body.images.some((url) => typeof url !== "string" || !url.trim() || !/^https?:\/\//i.test(url.trim()))
    ) {
      errors.push("Images must be an array of up to 12 HTTP/HTTPS image URLs.");
    }
  }
  for (const field of ["featured", "showOnWebsite"]) {
    if (body[field] !== undefined && typeof body[field] !== "boolean") {
      errors.push(`${field} must be true or false.`);
    }
  }
  for (const field of ["grossWeight", "netWeight"]) {
    if (body[field] !== undefined && body[field] !== null) {
      const value = Number(body[field]);
      if (!Number.isFinite(value) || value < 0) {
        errors.push(`${field} must be a non-negative number.`);
      }
    }
  }
  return errors;
};

const getUniqueSlug = async (name, excludeId = null) => {
  const base = makeSlug(name);
  if (!base) {
    const error = new Error("Product name must contain letters or numbers.");
    error.status = 400;
    throw error;
  }
  let slug = base;
  let counter = 2;
  while (true) {
    const filter = { slug };
    if (excludeId) filter._id = { $ne: excludeId };
    const exists = await Product.exists(filter);
    if (!exists) return slug;
    slug = `${base}-${counter++}`;
  }
};

// GET /api/v1/products — public catalogue; intentionally excludes inactive/hidden/deleted products.
const getPublicProducts = async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(48, Math.max(1, parseInt(req.query.limit, 10) || 12));
    const filter = { isActive: true, showOnWebsite: true, isDeleted: false };

    const category = String(req.query.category || "").trim();
    if (category && category !== "All Jewellery" && category !== "all") {
      if (!PRODUCT_CATEGORIES.includes(category)) {
        return res.status(400).json({ success: false, message: "Invalid product category." });
      }
      filter.category = category;
    }

    const search = String(req.query.search || "").trim();
    if (search) {
      const regex = new RegExp(escapeRegex(search), "i");
      filter.$or = [{ name: regex }, { description: regex }, { sku: regex }, { category: regex }];
    }

    if (String(req.query.featured || "").toLowerCase() === "true") {
      filter.featured = true;
    }

    const [products, total] = await Promise.all([
      Product.find(filter)
        .select(publicProductFields)
        .sort({ featured: -1, createdAt: -1, _id: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Product.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: products,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasNextPage: page * limit < total,
        hasPreviousPage: page > 1,
      },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/v1/products/:slug — public product detail.
const getPublicProductBySlug = async (req, res, next) => {
  try {
    const product = await Product.findOne({
      slug: req.params.slug,
      isActive: true,
      showOnWebsite: true,
      isDeleted: false,
    })
      .select(publicProductFields)
      .lean();

    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }
    res.status(200).json({ success: true, data: product });
  } catch (error) {
    next(error);
  }
};

// GET /api/v1/products/admin/all — authenticated CRM product list.
const getAdminProducts = async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const filter = { isDeleted: String(req.query.includeDeleted || "") === "true" ? true : false };

    const status = String(req.query.status || "all").toLowerCase();
    if (status === "active") filter.isActive = true;
    if (status === "inactive") filter.isActive = false;

    const category = String(req.query.category || "").trim();
    if (category && category !== "all") {
      if (!PRODUCT_CATEGORIES.includes(category)) {
        return res.status(400).json({ success: false, message: "Invalid product category." });
      }
      filter.category = category;
    }

    const search = String(req.query.search || "").trim();
    if (search) {
      const regex = new RegExp(escapeRegex(search), "i");
      filter.$or = [{ name: regex }, { sku: regex }, { description: regex }, { slug: regex }];
    }

    const [products, total] = await Promise.all([
      Product.find(filter)
        .populate("createdBy", "name email")
        .populate("updatedBy", "name email")
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Product.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: products,
      pagination: { total, page, limit, totalPages: Math.ceil(total / limit) },
    });
  } catch (error) {
    next(error);
  }
};

const createProduct = async (req, res, next) => {
  try {
    const errors = validateProductInput(req.body || {});
    if (errors.length) {
      return res.status(400).json({ success: false, message: errors[0], errors });
    }

    const data = {};
    for (const field of ALLOWED_FIELDS) {
      if (req.body[field] !== undefined) data[field] = req.body[field];
    }

    data.name = data.name.trim();
    data.slug = await getUniqueSlug(data.name);
    if (data.sku) data.sku = String(data.sku).trim().toUpperCase();
    if (data.images) data.images = data.images.map((url) => url.trim());
    data.createdBy = req.user?._id || null;
    data.updatedBy = req.user?._id || null;

    const product = await Product.create(data);
    res.status(201).json({
      success: true,
      message: "Product created successfully.",
      data: product,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "A product with this identifier already exists." });
    }
    next(error);
  }
};

const updateProduct = async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid product ID." });
    }

    const errors = validateProductInput(req.body || {}, true);
    if (errors.length) {
      return res.status(400).json({ success: false, message: errors[0], errors });
    }

    const product = await Product.findOne({ _id: req.params.id, isDeleted: false });
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }

    const updates = {};
    for (const field of ALLOWED_FIELDS) {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) updates[field] = req.body[field];
    }
    if (Object.prototype.hasOwnProperty.call(updates, "name")) {
      updates.name = String(updates.name).trim();
      if (!updates.name) {
        return res.status(400).json({ success: false, message: "Product name cannot be empty." });
      }
      updates.slug = await getUniqueSlug(updates.name, product._id);
    }
    if (updates.sku !== undefined) updates.sku = String(updates.sku || "").trim().toUpperCase();
    if (updates.images !== undefined) updates.images = updates.images.map((url) => url.trim());

    Object.assign(product, updates, { updatedBy: req.user?._id || null });
    await product.save();

    res.status(200).json({ success: true, message: "Product updated successfully.", data: product });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "Product slug or SKU already exists." });
    }
    next(error);
  }
};

const updateProductStatus = async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid product ID." });
    }
    if (typeof req.body?.isActive !== "boolean") {
      return res.status(400).json({ success: false, message: "isActive must be true or false." });
    }

    const product = await Product.findOneAndUpdate(
      { _id: req.params.id, isDeleted: false },
      { $set: { isActive: req.body.isActive, updatedBy: req.user?._id || null } },
      { new: true, runValidators: true }
    );
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }
    res.status(200).json({
      success: true,
      message: `Product ${product.isActive ? "activated" : "deactivated"} successfully.`,
      data: product,
    });
  } catch (error) {
    next(error);
  }
};

const softDeleteProduct = async (req, res, next) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid product ID." });
    }
    const product = await Product.findOneAndUpdate(
      { _id: req.params.id, isDeleted: false },
      { $set: { isDeleted: true, isActive: false, showOnWebsite: false, updatedBy: req.user?._id || null } },
      { new: true }
    );
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }
    res.status(200).json({ success: true, message: "Product moved to deleted items.", data: product });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getPublicProducts,
  getPublicProductBySlug,
  getAdminProducts,
  createProduct,
  updateProduct,
  updateProductStatus,
  softDeleteProduct,
};
